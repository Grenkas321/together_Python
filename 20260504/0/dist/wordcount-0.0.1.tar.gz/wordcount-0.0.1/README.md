"Word counter"
